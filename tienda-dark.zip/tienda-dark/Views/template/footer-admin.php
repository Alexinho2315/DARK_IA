</div><!-- container fluid -->

</div> <!-- Page content Wrapper -->

</div> <!-- content -->

<footer class="footer">
  © <?php echo date('Y'); ?> <span class="d-none d-md-inline-block"><i class="mdi mdi-heart text-danger"></i> </span>
</footer>

</div>
<!-- End Right content here -->

</div>
<!-- END wrapper -->


<!-- jQuery  -->
<script src="<?php echo BASE_URL; ?>public/admin/js/jquery.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/modernizr.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/detect.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/fastclick.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/jquery.slimscroll.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/jquery.blockUI.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/waves.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/jquery.nicescroll.js"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/jquery.scrollTo.min.js"></script>

<!-- App js -->
<script src="<?php echo BASE_URL; ?>public/admin/js/app.js"></script>

<script src="<?php echo BASE_URL; ?>public/js/all.min.js"></script>
<script src="<?php echo BASE_URL; ?>public/js/sweetalert2.all.min.js"></script>
<script>
  const base_url = '<?php echo BASE_URL; ?>';
</script>
<script type="text/javascript" src="<?php echo BASE_URL . 'public/admin/DataTables/datatables.min.js'; ?>"></script>
<script src="<?php echo BASE_URL; ?>public/admin/js/es-ES.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>public/js/toastify-js.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>public/admin/js/custom.js"></script>
