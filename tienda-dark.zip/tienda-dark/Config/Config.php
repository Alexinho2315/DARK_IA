<?php
const BASE_URL = "http://localhost/tienda-dark/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "shop";
const CHARSET = "charset=utf8";
const TITLE = "SHOP";
const MONEDA = "USD";
const CLIENT_ID = "Ac0PgehcTe9tdOMqlC2z7sW8l7BCj1hO9RPo3qkHVw8-wBSCos0flhHjuG5e9oM99mEqxuG2I2pMzMOL";
?>
